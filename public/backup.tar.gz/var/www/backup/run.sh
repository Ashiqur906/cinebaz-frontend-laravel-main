#!/bin/bash


clear
pre_date=$(date -d "7 days ago" +"%d_%m_%Y")
today=$(date "+%d_%m_%Y")
pre_folder="/var/www/backup/$pre_date"
today_folder="/var/www/backup/$today"

if [ -d "$pre_folder" ]
then 
     rm -r "$pre_folder"
     mkdir "$today_folder"
else
    if [ -d "$today_folder" ]
    then 
        rm -r "$today_folder"
        mkdir "$today_folder"
    else
        mkdir "$today_folder"
    fi
   
fi


if [ -d "$today_folder" ]
then

    mysqldump --single-transaction --no-tablespaces -h 127.0.0.1 -P 3306 -u cbazdev -pdev@Cbaz2021 cinebaz_dev > $today_folder/cinebaz_dev.sql
fi

echo "Today Backup successful"
